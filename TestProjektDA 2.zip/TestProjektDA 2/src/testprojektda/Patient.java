/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

import java.util.Date;

/**
 *
 * @author July
 */
public class Patient {
    
    Person p; 
 Date geburtsdatum; 
    String svnr; 
    String telnr; 
    
    int PatientID; 

    public Person getP() {
        return p;
    }

    public void setP(Person p) {
        this.p = p;
    }

    public Date getGeburtsdatum() {
        return geburtsdatum;
    }

    public void setGeburtsdatum(Date geburtsdatum) {
        this.geburtsdatum = geburtsdatum;
    }

    public String getSvnr() {
        return svnr;
    }

    public void setSvnr(String svnr) {
        this.svnr = svnr;
    }

    public String getTelnr() {
        return telnr;
    }

    public void setTelnr(String telnr) {
        this.telnr = telnr;
    }

    public int getPatientID() {
        return PatientID;
    }

    public void setPatientID(int PatientID) {
        this.PatientID = PatientID;
    }

    public Patient(Person p, Date geburtsdatum, String svnr, String telnr, int PatientID) {
        this.p = p;
        this.geburtsdatum = geburtsdatum;
        this.svnr = svnr;
        this.telnr = telnr;
        this.PatientID = PatientID;
    }
    
    
    
    
   
    
}
