/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

import java.util.Date;

/**
 *
 * @author July
 */
public class Datum {
    
    Boolean neun=false; 
    Boolean zehn=false; 
    Boolean elf=false; 
    Boolean zwoelf=false; 
    Boolean dreizehn=false; 
    Boolean vierzehn=false; 
    Boolean fuenfzehn=false; 
    Boolean sechzehn=false; 
    
    Date datetermin= new Date(); 

    public Datum(Boolean neun, Boolean zehn, Boolean elf, Boolean zwoelf, Boolean dreizehn, Boolean vierzehn, Boolean fuenfzehn, Boolean sechzehn,Date datetermin ) {
        this.neun= neun; 
        this.zehn= zehn; 
        this.elf=elf; 
        this.zwoelf=zwoelf; 
        this.dreizehn= dreizehn; 
        this.vierzehn=vierzehn; 
        this.fuenfzehn=fuenfzehn; 
        this.sechzehn=sechzehn; 
        this.datetermin=datetermin;
    }

    public Boolean getNeun() {
        return neun;
    }

    public void setNeun(Boolean neun) {
        this.neun = neun;
    }

    public Boolean getZehn() {
        return zehn;
    }

    public void setZehn(Boolean zehn) {
        this.zehn = zehn;
    }

    public Boolean getElf() {
        return elf;
    }

    public void setElf(Boolean elf) {
        this.elf = elf;
    }

    public Boolean getZwoelf() {
        return zwoelf;
    }

    public void setZwoelf(Boolean zwoelf) {
        this.zwoelf = zwoelf;
    }

    public Boolean getDreizehn() {
        return dreizehn;
    }

    public void setDreizehn(Boolean dreizehn) {
        this.dreizehn = dreizehn;
    }

    public Boolean getVierzehn() {
        return vierzehn;
    }

    public void setVierzehn(Boolean vierzehn) {
        this.vierzehn = vierzehn;
    }

    public Boolean getFuenfzehn() {
        return fuenfzehn;
    }

    public void setFuenfzehn(Boolean fuenfzehn) {
        this.fuenfzehn = fuenfzehn;
    }

    public Boolean getSechzehn() {
        return sechzehn;
    }

    public void setSechzehn(Boolean sechzehn) {
        this.sechzehn = sechzehn;
    }

    public Date getDatetermin() {
        return datetermin;
    }

    public void setDatetermin(Date datetermin) {
        this.datetermin = datetermin;
    }

   

  
    
    
    
}
