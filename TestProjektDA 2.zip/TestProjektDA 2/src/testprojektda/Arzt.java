/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

import java.util.LinkedList;

/**
 *
 * @author July
 */
public class Arzt {
    
    Person p; 
    LinkedList<String>qualis= new LinkedList<>(); 
int ArztID;
 
    

    public Arzt(Person p, LinkedList<String> qualis, int ArztID) {
        this.p = p;
        this.qualis=qualis;
        this.ArztID=this.ArztID;
        
       
    }

    public Person getP() {
        return p;
    }

    public void setP(Person p) {
        this.p = p;
    }

    public LinkedList<String> getQualis() {
        return qualis;
    }

    public void setQualis(LinkedList<String> qualis) {
        this.qualis = qualis;
    }

    @Override
    public String toString() {
        return "Arzt{" + "p=" + p + ", qualis=" + qualis + '}';
    }

    public int getArztID() {
        return ArztID;
    }

    public void setArztID(int ArztID) {
        this.ArztID = ArztID;
    }

   

    
    
    
    
            
            
            
    
    
    
}
