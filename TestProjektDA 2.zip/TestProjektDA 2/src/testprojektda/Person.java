/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

/**
 *
 * @author July
 */
public class Person {
    
    String vorname; 
    String nachname; 
    int PersonID; 

    public Person(String vorname, String nachname, int PersonID) {
        this.vorname = vorname;
        this.nachname = nachname;
        this.PersonID=PersonID; 
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getNachname() {
        return nachname;
    }

    public void setNachname(String nachname) {
        this.nachname = nachname;
    }

    @Override
    public String toString() {
        return ""+vorname+""+nachname;
    }

    public int getPersonID() {
        return PersonID;
    }

    public void setPersonID(int PersonID) {
        this.PersonID = PersonID;
    }
    
    
    
    
}
