/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

import java.util.LinkedList;

/**
 *
 * @author July
 */
public class Pflegepersonal {
    
    Person p; 
    LinkedList<String>qualis2= new LinkedList<>(); 
int PflegepersonalID;

    public Pflegepersonal(Person p, int PflegepersonalID, LinkedList<String> quali2) {
        this.p = p;
        this.PflegepersonalID = PflegepersonalID;
        this.qualis2=qualis2;
    }

    public Person getP() {
        return p;
    }

    public void setP(Person p) {
        this.p = p;
    }

    public LinkedList<String> getQualis2() {
        return qualis2;
    }

    public void setQualis2(LinkedList<String> qualis2) {
        this.qualis2 = qualis2;
    }

    public int getPflegepersonalID() {
        return PflegepersonalID;
    }

    public void setPflegepersonalID(int PflegepersonalID) {
        this.PflegepersonalID = PflegepersonalID;
    }
 
    




    
    
    
    
}
