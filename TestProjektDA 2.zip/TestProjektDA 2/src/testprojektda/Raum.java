/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testprojektda;

import java.util.LinkedList;

/**
 *
 * @author July
 */
public class Raum {
    
   int  RaumID; 

    LinkedList<String>qualis= new LinkedList<>(); 

    public Raum(int RaumID, LinkedList<String> qualis) {
        this.RaumID = RaumID;
        this.qualis=qualis; 
    }

    public int getRaumID() {
        return RaumID;
    }

    public void setRaumID(int RaumID) {
        this.RaumID = RaumID;
    }

    public LinkedList<String> getQualis() {
        return qualis;
    }

    public void setQualis(LinkedList<String> qualis) {
        this.qualis = qualis;
    }

 
    
    
}
